package com.example.liamstickney.assignment_2.Model;

/**
 * Created by liamstickney on 2018-09-26.
 */


/*
 the question class that is used in the mainActivity
 has two constructors, question and answer, where the question is
 a string and the answer is a boolean
 also has the methods getQuestion and getAnswer, which return the
 question and answer of the particular question
 also has the method getQuestions, which creates an arraylist of the questions
 in the quiz game and returns them
 */

import java.util.ArrayList;

public class Question {

    private String question;
    private boolean answer;

    public Question(String question, boolean answer) {
        this.question = question;
        this.answer = answer;
    }


    public String getQuestion() { return question; }

    public boolean getAnswer() { return answer; }

    public static ArrayList<Question> getQuestions() {

        ArrayList<Question> questions = new ArrayList<>();

        questions.add(new Question("There are 6 Canadian NHL teams", false));
        questions.add(new Question("Canada was founded in 1867", true));
        questions.add(new Question("Canada has 10 provinces", true));
        questions.add(new Question("Canada won the Hockey gold medal at the 2018 olympics", false));
        questions.add(new Question("As of 2012, the Bank of Montreal is the richest Canadian company", false));
        questions.add(new Question("More people live in California than in Canada", true));
        questions.add(new Question("Canada is the largest country in the world", false));

        return questions;
    }

}