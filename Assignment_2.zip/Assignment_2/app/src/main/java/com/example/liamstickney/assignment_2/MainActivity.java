package com.example.liamstickney.assignment_2;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;

import com.example.liamstickney.assignment_2.Model.Question;

import java.util.ArrayList;
import java.util.Collections;
//within the strings.xml, how to retain whitespace was obtained here: https://stackoverflow.com/questions/1587056/how-to-keep-the-spaces-at-the-end-and-or-at-the-beginning-of-a-string
public class MainActivity extends Activity {

    /*
    creating variables including the three textviews used for displaying information
    two ints and one double used for the current question number, the highscore and the point total
    for a specific round (it is a double because it is divided to retrieve a percent equivalent
    the start boolean is created and is only used upon starting of the application, then it is always false
    a boolean 'restart' is originally defined as false but is changed to true when all of the questions
    have been answered; hitting the next question button when it is true resets the quiz entirely (except
    for the high score, that is always preserved)
     also sets variables for the buttons, the arraylist where the questions will be and the sharedpreferences
    */

    private TextView txt_question;
    private TextView txt_result;
    private TextView txt_HighScore;
    private int questionNum;
    private double pointTotal;
    public boolean restart;
    private boolean start;
    private int highScore;

    private Button btn_True;
    private Button btn_False;
    private Button btn_Next;
    private ArrayList<Question> questionLst;
    private SharedPreferences sharedPref;



    /*
    points the buttons to the button widgets in the activity_main
    also points the textviews to the activity_main
    sets the current question number and score to 0 (as 0 is the first object in the arraylist)
    creates the arraylist which is filled by calling the getQuestions() method in the Question class
    which returns the questions defined there (the questions are then shuffled)
    the Collections.shuffle method retrieved from https://stackoverflow.com/questions/16112515/how-to-shuffle-an-arraylist
    also creates a shared preferences which will save the value of the high score between runs
    the initial value of highscore is 0, which is updated upon first completion of quiz
    the text of the question textview is then set to the first question in the arraylist
    the next question button is also grayed out so the user must answer the
    first question first
    */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_True = findViewById(R.id.btn_true);
        btn_False = findViewById(R.id.btn_false);
        btn_Next = findViewById(R.id.btn_next);


        txt_question = findViewById(R.id.txt_question);
        txt_result = findViewById(R.id.txt_result);
        txt_HighScore = findViewById(R.id.txt_HighScore);

        questionNum = 0;
        pointTotal = 0;
        restart = false;
        start = true;

        questionLst = Question.getQuestions();
        Collections.shuffle(questionLst);

        sharedPref = getPreferences(Context.MODE_PRIVATE);

        btn_True.setEnabled(false);
        btn_False.setEnabled(false);




        /*
        upon clicking the true button, this method is called
        first the method is called that switches all of the buttons' enabled status
        upon hitting the button, the question corresponding to the current number's
        answer is checked; if it is true, the answer is correct and the user is given a point.
        if not, the answer is incorrect and nothing happens
        finally, if the question number is now equal to the size of the arraylist - 1 (the last question),
        the quizOver method is called, which calculates the score and enters the highscore
        */
        btn_True.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeButton();
                if (questionLst.get(questionNum).getAnswer()) {
                    txt_result.setText(getString(R.string.answer_correct));
                    pointTotal++;
                } else {
                    txt_result.setText(R.string.answer_wrong);
                }
                if (questionNum >= questionLst.size() - 1) {
                    quizOver();
                }
            }
        });

        /*
        this is the method for the false button
        works similarly to the true button, but adds score if the boolean of the
        question is false rather than true
        */

        btn_False.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeButton();
                if (!questionLst.get(questionNum).getAnswer()) {
                    txt_result.setText(R.string.answer_correct);
                    pointTotal++;
                } else {
                    txt_result.setText(R.string.answer_wrong);
                }
                if (questionNum >= questionLst.size() - 1) {
                    quizOver();
                }

            }
        });

        /*
        the method for the next button
        first checks if the start boolean is true (if it is, quiz begins and the first
        question is shown)
        then checks if the restart boolean is true, which is only
        true if the quiz has been completed
        if it is, the restart boolean is reset to false, the point total and the
        question number are both reset to 0, the question list is shuffled again and
        the new first question is displayed. the buttons for true and false are enabled and
        the next button is once again disabled and the text fields are cleared.
        if restart is not true, this button just swaps the enable values of the buttons,
        resets the result textview and changes the question to the next one in the list

        */
        btn_Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (start) {
                    txt_question.setText(questionLst.get(questionNum).getQuestion());
                    btn_Next.setText(getString(R.string.next_question));
                    btn_True.setEnabled(true);
                    btn_False.setEnabled(true);
                    btn_Next.setEnabled(false);
                    start = false;
                    return;
                }

                if (restart) {
                    restart = false;
                    pointTotal = 0;
                    btn_Next.setText(getString(R.string.next_question));
                    Collections.shuffle(questionLst);
                    questionNum = 0;
                    txt_question.setText(questionLst.get(questionNum).getQuestion());
                    btn_True.setEnabled(true);
                    btn_False.setEnabled(true);
                    btn_Next.setEnabled(false);
                    txt_result.setText("");
                    txt_HighScore.setText("");
                    return;
                }

                btn_True.setEnabled(true);
                btn_False.setEnabled(true);
                btn_Next.setEnabled(false);
                txt_result.setText("");
                questionNum++;
                txt_question.setText(questionLst.get(questionNum).getQuestion());
            }
        });
    }

    /*
     method that changes the enabled status of the buttons
     when clicking the true or false buttons
     */
    public void changeButton() {
        btn_False.setEnabled(false);
        btn_True.setEnabled(false);
        btn_Next.setEnabled(true);
    }

    /*
     this method is called by the true and false buttons when the last question
     has been answered
     the user's score is displayed as a number and as a percentage
     the percentage is rounded to avoid needlessly long decimal values (and is converted to an int)
     the text of the next button is changed to start over, and the restart boolean becomes true
     the value of high score inside the shared preferences is then compared to the pointTotal value
     for that specific round
     if the point total is greater than the high score value, it replaces the old high score value
     in the shared preferences
     the highscore is then displayed regardless of if it was updated in the last round
     */

    public void quizOver() {
        txt_question.setText(String.format(getString(R.string.quiz_over), (int) pointTotal) + String.format(getString(R.string.out_of), questionLst.size()) +  String.format(getString(R.string.or), Math.round((pointTotal / questionLst.size()) * 100)) + getString(R.string.percentage));
        btn_Next.setText(getString(R.string.start_over));
        restart = true;
        if (sharedPref.getInt(getString(R.string.sharedpreference_id), highScore) < pointTotal) {
            highScore = (int) pointTotal;
            sharedPref.edit().putInt(getString(R.string.sharedpreference_id), highScore).apply();
        }
        txt_HighScore.setText(getString(R.string.high_score_display) + sharedPref.getInt(getString(R.string.sharedpreference_id), highScore));
    }

}





